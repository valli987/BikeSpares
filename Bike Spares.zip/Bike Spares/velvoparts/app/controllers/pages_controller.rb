class PagesController < ApplicationController
  def index    # Home page
  end

  def about
  end

  

  def blog
  end

  def contact
  end
end
