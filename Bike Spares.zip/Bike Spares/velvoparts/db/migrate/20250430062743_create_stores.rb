class CreateStores < ActiveRecord::Migration[7.2]
  def change
    create_table :stores do |t|
      t.string :Sparepart_Name
      t.string :Bike_Model
      t.integer :Year_of_Manufacture
      t.string :Color

      t.timestamps
    end
  end
end
