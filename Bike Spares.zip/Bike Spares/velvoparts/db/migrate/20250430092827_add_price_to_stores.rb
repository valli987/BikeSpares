class AddPriceToStores < ActiveRecord::Migration[7.2]
  def change
    add_column :stores, :price, :integer
  end
end
