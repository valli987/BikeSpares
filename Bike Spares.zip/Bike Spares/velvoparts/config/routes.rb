# config/routes.rb
Rails.application.routes.draw do
  resources :line_items
  resources :carts
  resources :line_items, only: [:destroy]
  resources :carts do
    delete "destroy_all", on: :member  # for "Empty Cart" button
  end

  # Devise routes
  devise_for :users

  # Admin routes
  get "admin/login"
  post "admin/login"
  get "admin/logout"

  # Gallery routes
  get "gallery/index"
  get "gallery/search"
  get "gallery/checkout"
  post "gallery/checkout"
  get "gallery/purchase_complete"

  # Store routes
  resources :stores

  # Page routes
  get 'about', to: 'pages#about'
  get 'pages/index', to: 'pages#index', as: 'gallery'
  
  # Explicitly define bikes path
  get 'bikes', to: 'gallery#index'  # Add this line to make '/bikes' route to 'gallery#index'

  get 'blog', to: 'pages#blog'
  get 'contact', to: 'pages#contact'
  root 'pages#index'

  # Home route
  get "home/index"

  # Health check route
  get "up" => "rails/health#show", as: :rails_health_check

  # PWA routes
  get "service-worker" => "rails/pwa#service_worker", as: :pwa_service_worker
  get "manifest" => "rails/pwa#manifest", as: :pwa_manifest
end
